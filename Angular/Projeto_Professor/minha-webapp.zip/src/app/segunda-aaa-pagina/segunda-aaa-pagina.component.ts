import { Component } from '@angular/core';

@Component({
  selector: 'app-segunda-aaa-pagina',
  standalone: true,
  imports: [],
  templateUrl: './segunda-aaa-pagina.component.html',
  styleUrl: './segunda-aaa-pagina.component.scss'
})
export class SegundaAaaPaginaComponent {

}
